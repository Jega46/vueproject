<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>


export default {
  name: 'App',
};


</script>

<style>
body {
  font-family: "Poppins", sans-serif;
  font-weight: 300;
  font-style: normal;
  font-size: 15px;

  padding: 0px;
  background-color: rgb(243, 240, 240);
}
</style>
